"use strict";

module.exports = require("./src/index");
