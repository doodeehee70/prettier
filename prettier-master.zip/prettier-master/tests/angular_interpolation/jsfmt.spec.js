run_spec(__dirname, ["__ng_interpolation"]);
