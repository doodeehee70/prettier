class Something {
    @Annotateme()
    // comment
    static property: Array<string>;
}
