div {
  height: calc(-0.5 * var(ei-table-cell-padding));
  width: -webkit-calc(100% + 20px);
  margin: -moz-calc(100% - 320px);
  background: url(var(audience-network-checkbox-image)) center no-repeat;
  background-image: url() center center no-repeat black;
}
