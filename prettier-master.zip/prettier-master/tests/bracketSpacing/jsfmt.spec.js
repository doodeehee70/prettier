run_spec(__dirname, ["flow", "typescript"]);
run_spec(__dirname, ["flow", "typescript"], { bracketSpacing: false });
