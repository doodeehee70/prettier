let {
  bottom: offsetBottom,
  left: offsetLeft,
  right: offsetRight,
  top: offsetTop,
} = getPressRectOffset == null ? DEFAULT_PRESS_RECT : getPressRectOffset();

const { accessibilityModule: FooAccessibilityModule, accessibilityModule: FooAccessibilityModule, accessibilityModule: FooAccessibilityModule, accessibilityModule: FooAccessibilityModule,
      } = foo || {};

({ prop: toAssign = "default" } = { prop: "propval" });
