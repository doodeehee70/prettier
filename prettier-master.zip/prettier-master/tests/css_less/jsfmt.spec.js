run_spec(__dirname, ["less"]);
