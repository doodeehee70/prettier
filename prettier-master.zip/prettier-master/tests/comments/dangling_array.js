expect(() => {}).toTriggerReadyStateChanges([
  // Nothing.
]);

[1 /* first comment */, 2 /* second comment */, 3];
