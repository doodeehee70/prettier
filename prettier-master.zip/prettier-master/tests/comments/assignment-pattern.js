const { a /* comment */ = 1 } = b;

const { c = 1 /* comment */ } = d;

let {a //comment
= b} = c
