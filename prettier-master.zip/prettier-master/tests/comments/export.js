export //comment
{}

export /* comment */ {};

export {
  foo // comment
}

export {
  // comment
  bar
}

export {
  fooo, // comment
  barr, // comment
}
