while(
    true
    // Comment
  ) {}

while(true)// Comment
{}

while(true){}// Comment

while(true)/*Comment*/{}

while(
  true // Comment
  && true // Comment
  ){}

while(true) {} // comment

while(true) /* comment */ ++x; 
