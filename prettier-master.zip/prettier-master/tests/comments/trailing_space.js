#!/there/is-space-here->         

// Do not trim trailing whitespace from this source file!

// There is some space here ->                        
