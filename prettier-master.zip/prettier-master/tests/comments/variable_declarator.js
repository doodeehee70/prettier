let obj = // Comment
{
  key: 'val'
}

let obj // Comment
= {
  key: 'val'
}

let obj = { // Comment
  key: 'val'
}

let obj = {
  // Comment
  key: 'val'
}

let obj = // Comment
[
  'val'
]

let obj // Comment
= [
  'val'
]

let obj = [ // Comment
  'val'
]

let obj = [
  // Comment
  'val'
]

let obj = // Comment
`val`;

let obj = // Comment
`
val
val
`;

let obj = // Comment
tag`val`;

let obj = // Comment
tag`
val
val
`;

let // Comment
  foo = 'val';

let // Comment
  foo = 'val',
  bar = 'val';

const foo = 123
// Nothing to see here.
;["2", "3"].forEach(x => console.log(x))
