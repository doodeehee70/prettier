const foo = {
  a: 'a' /* comment for this line */,

  /* Section B */
  b: 'b',
};
