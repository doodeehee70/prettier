const result = (a + b) >>> 1;
var sizeIndex = ((index - 1) >>> level) & MASK;
var from = offset > left ? 0 : (left - offset) >> level;
var to = ((right - offset) >> level) + 1;
if (rawIndex < 1 << (list._level + SHIFT)) {}
var res = size < SIZE ? 0 : (((size - 1) >>> SHIFT) << SHIFT);
sign = 1 - (2 * (b[3] >> 7));
exponent = (((b[3] << 1) & 0xff) | (b[2] >> 7)) - 127;
mantissa = ((b[2] & 0x7f) << 16) | (b[1] << 8) | b[0];

2 / 3 * 10 / 2 + 2;
const rotateX = ((RANGE / rect.height) * refY - RANGE / 2) * getXMultiplication(rect.width);
const rotateY = ((RANGE / rect.width) * refX - RANGE / 2) * getYMultiplication(rect.width);

a % 10 - 5;
a * b % 10;
a % 10 > 5;
a % 10 == 0;
