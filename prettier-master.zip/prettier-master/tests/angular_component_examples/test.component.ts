@Component({
       selector: 'app-test',
  template: `<ul>   <li>test</li>
  </ul>
  `,
  styles: [   `
  
 :host {
   color: red;
 } 
 div { background: blue
 }
`

]
})
class     TestComponent {}
