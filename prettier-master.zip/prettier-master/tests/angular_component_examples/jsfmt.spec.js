run_spec(__dirname, ["typescript"]);
run_spec(__dirname, ["typescript"], { trailingComma: "es5" });
