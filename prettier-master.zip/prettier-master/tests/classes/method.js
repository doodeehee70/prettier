
class C {
  name/*comment*/() {
  }
};


({
  name/*comment*/() {
  }
});
