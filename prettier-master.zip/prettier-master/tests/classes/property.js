class A {
  foobar =
    // comment to break
    1 +
    // comment to break again
    2;
}

class B {
  someInstanceProperty = this.props.foofoofoofoofoofoo &&
    this.props.barbarbarbar;
  
  someInstanceProperty2 = { foo: this.props.foofoofoofoofoofoo &&
    this.props.barbarbarbar };
  
    someInstanceProperty3 =
  "foo";
}
