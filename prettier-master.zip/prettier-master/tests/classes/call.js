(class {})(class {});
