class A {
  // comment
}

class A { // comment
}

class A {
}

class A {
  m() {}
}
