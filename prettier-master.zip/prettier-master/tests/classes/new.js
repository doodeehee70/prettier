new class {};
new Ctor(class {});
