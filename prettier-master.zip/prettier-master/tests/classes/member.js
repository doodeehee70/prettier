(class {})[1];
(class {}).a;
