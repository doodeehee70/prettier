if (1) (class {}) ? 1 : 2;
