
foo  <|>  (bar);
