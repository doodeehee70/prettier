thisWontBeFormatted <|> ( 1  ,3<<<PRETTIER_RANGE_START>>>)

    thisWillBeFormatted    (2  ,3,   )

 <<<PRETTIER_RANGE_END>>>   thisWontBeFormatted  (2, 90  ,)
    