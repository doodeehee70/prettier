

  const y = 5

  <|>

  const z = 9
