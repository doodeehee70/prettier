const      y    /* h<|>i */   = 5
