const    /* h<|>i */    y = 5
