// hi l<|>ol
function ehllooo () {
  const hi = "hi"
}
