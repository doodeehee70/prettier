run_spec(__dirname, ["flow", "babel", "typescript"], {
  jsxBracketSameLine: true
});
