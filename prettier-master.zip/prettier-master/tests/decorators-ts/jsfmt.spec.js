run_spec(__dirname, ["typescript"]);
