fnString =
  // Comment
  'some' + 'long' + 'string';

var fnString =
  // Comment
  'some' + 'long' + 'string';

var fnString =
  // Comment

  'some' + 'long' + 'string';

var fnString =

  // Comment

  'some' + 'long' + 'string';

var fnString =
  /* comment */
  'some' + 'long' + 'string';

var fnString =
  /**
   * multi-line
   */
  'some' + 'long' + 'string';

var fnString =
  /* inline */ 'some' + 'long' + 'string' + 'some' + 'long' + 'string' + 'some' + 'long' + 'string' + 'some' + 'long' + 'string';

var fnString = // Comment
  // Comment
  'some' + 'long' + 'string';

var fnString = // Comment
  'some' + 'long' + 'string';

let f = (
  a =
  //comment
  b
) => {};

let f = (
  a = //comment
  b
) => {};

let f = (
  a =
  b //comment
) => {};
