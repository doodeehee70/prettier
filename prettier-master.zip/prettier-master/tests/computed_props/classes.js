class c {
  ["i"]() {}
}
