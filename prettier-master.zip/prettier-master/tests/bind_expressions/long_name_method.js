class X {
  constructor() {
    this.testLongNameMethodAndSomethingElseLallala = ::this.testLongNameMethodAndSomethingElseLallala;
  }
  
  testLongNameMethodAndSomethingElseLallala() {
    return true;
  }
}