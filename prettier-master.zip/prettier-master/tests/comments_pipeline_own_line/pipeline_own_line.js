function pipeline() {
	0
	// Comment
	|> x
}
