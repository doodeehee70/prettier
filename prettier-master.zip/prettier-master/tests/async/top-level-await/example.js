await something();
