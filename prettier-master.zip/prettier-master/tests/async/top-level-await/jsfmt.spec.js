run_spec(__dirname, ["babel", "typescript"]);
