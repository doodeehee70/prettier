if (this.hasPlugin("dynamicImports") && this.lookahead().type) {}

if (this.hasPlugin("dynamicImports") && this.lookahead().type === tt.parenLeft) {}

if (this.hasPlugin("dynamicImports") && this.lookahead().type === tt.parenLeft.right) {}

if (VeryVeryVeryVeryVeryVeryVeryVeryLong === VeryVeryVeryVeryVeryVeryVeryVeryLong) {
}
